const input = document.getElementById('inputText');
const output = document.getElementById('outputText');

// Aturan transliterasi sederhana (bisa disesuaikan)
function transliterate(text) {
  const rules = {
    'a': 'u',
    'i': 'e',
    'u': 'a',
    'e': 'i',
    'o': 'o',
    'ng': 'ŋ',
    'ny': 'ɲ',
  };

  let result = text;

  result = result.replace(/ng/g, rules['ng']);
  result = result.replace(/ny/g, rules['ny']);

  for (const [latin, target] of Object.entries(rules)) {
    if (latin.length === 1) {
      const regex = new RegExp(latin, 'g');
      result = result.replace(regex, target);
    }
  }

  return result;
}

input.addEventListener('input', () => {
  output.value = transliterate(input.value);
});
